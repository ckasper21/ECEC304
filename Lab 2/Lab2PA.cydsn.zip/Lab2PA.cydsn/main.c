/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
int bpress=1;
int increment=1;
int decrement=0;

CY_ISR (switchISR)
{
    CyDelay(50); 
    while(!Pin_SW2_Read()); // wait till switch is released
    CyDelay(50);
    
    if (increment==1) // increment button presses
    {
        bpress++;
        if (bpress==5) // switch to decrement
        {
            increment=0;
            decrement=1;
        }
    } else
    {
        bpress--; // decrement button press
        if (bpress==1) // switch to decrement
        {
            increment=1;
            decrement=0;
        }
    }
    Pin_SW2_ClearInterrupt();
}
int main()
{
    CyGlobalIntDisable;
    Pin_SW2_Int_Start();
    Pin_SW2_Int_SetVector(switchISR);
    CyGlobalIntEnable; /* Enable global interrupts. */

    for(;;)
    {
        Pin_Red_Write(0);
        CyDelay(bpress*1000); // leave switch on for 1 sec * amount of button press
        Pin_Red_Write(1);
        CyDelay(bpress*1000);
    }
}

/* [] END OF FILE */