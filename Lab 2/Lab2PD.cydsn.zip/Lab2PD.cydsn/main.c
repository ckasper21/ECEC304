/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>
#include <stdlib.h>

#define MATRIX_SIZE 5

int tc,end_flag;
float elapsedTime=0,start=0,end=0;
char msg[20];

CY_ISR (uartISR)
{
    // UART ISR
    //Code to handle input
 
    // Clears interrupt
    UART_ClearRxInterruptSource(UART_GetRxInterruptSource());
}
CY_ISR (timerISR)
{
    //Timer ISR
    tc=tc+1;
    // Clears interrupt
    Timer_1_ReadStatusRegister(); 
}

void populateMatrix(float M[MATRIX_SIZE][MATRIX_SIZE])
{
    int8 i,j;
    for(i=0;i<MATRIX_SIZE;i++)
    {
        for(j=0;j<MATRIX_SIZE;j++)
        {
            M[i][j]=(float)rand()/(float)RAND_MAX;
        }
    }
}

void tic(void)
{
    //code
    start=tc;
}

void toc(void)
{
    //code
    end_flag=1;
    end=tc;
    elapsedTime=end-start;
}

void matrixMult(float A[MATRIX_SIZE][MATRIX_SIZE],\
                float B[MATRIX_SIZE][MATRIX_SIZE],\
                float C[MATRIX_SIZE][MATRIX_SIZE])
{
    int8 i,j,k;
    float temp;
    for(i=0;i<MATRIX_SIZE;i++)
    {
        for(j=0;j<MATRIX_SIZE;j++)
        {
            temp=0.0;
            for(k=0;k<MATRIX_SIZE;k++)
            {
                temp+=A[i][k]*B[k][j];
            }
            C[i][j]=temp;
        }
    }
}

int main()
{
    CyGlobalIntDisable;
    Uart_Int_Start();
    Uart_Int_SetVector(uartISR);
    Timer_Int_Start();
    Timer_Int_SetVector(timerISR);
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    Timer_1_Start();
    srand(rand());
    
    float A[MATRIX_SIZE][MATRIX_SIZE];
    float B[MATRIX_SIZE][MATRIX_SIZE];
    float C[MATRIX_SIZE][MATRIX_SIZE];

    for(;;)
    {
        populateMatrix(A);
        populateMatrix(B);
        
        tic();
        matrixMult(A,B,C);
        
        toc();
        
        /* Display elapseed time on terminal */
        if (end_flag==1)
        {
            int et=(int)elapsedTime; // have to type cast to int bc psoc creator float bug
            sprintf(msg,"Current calculation took %i milliseconds\n\r",et);  
            UART_UartPutString(msg);
            end_flag=0;
            CyDelay(1000);
            Timer_1_Init();
            Timer_1_Start();
            tc=0;
        }
    }
}
/* [] END OF FILE */