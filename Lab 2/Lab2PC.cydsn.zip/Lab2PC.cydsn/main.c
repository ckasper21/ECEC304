/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <stdio.h>

uint32 h2=0,h1=1,m2=0,m1=0,s2=0,s1=0,input=0;
char clock[8],display[2]; //clock display
int c_flag,timer_flag,uart_f1,uart_f2,uart_f3,uart_f4;

CY_ISR (uartISR)
{
    // UART ISR
    //Code to handle input
    input=UART_UartGetChar();
    if (input=='c')
    {
        c_flag=1;
        Timer_1_Stop();
        input=0;
    } else if ((input>47)&&(input<58))
    {
        uart_f1=1; // flag for s1,m1, h1(if h2 is 0)
        if (input<54)
        {
            uart_f2=2; // flag for s2,m2
            if (input<51)
            {
                uart_f3=1; // flag for h1(if h2 is 1)
                if (input<50)
                {
                    uart_f4=1; // flag for h2
                }
            }
        }
    }
    // Clears interrupt
    UART_ClearRxInterruptSource(UART_GetRxInterruptSource());
}
CY_ISR (timerISR)
{
    //Timer ISR
    timer_flag=1;
    // Clears interrupt
    Timer_1_ReadStatusRegister(); 
}
int main()
{
    CyGlobalIntDisable;
    Uart_Int_Start();
    Uart_Int_SetVector(uartISR);
    Timer_Int_Start();
    Timer_Int_SetVector(timerISR);
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    UART_UartPutString("Established connection to terminal...\r\n");
    // Initialize clock here
    c_flag=1;

    for(;;)
    {
        // code to trigger on timer interrupt flag
        if (timer_flag==1)
        {
            s1++;
            if (s1==10)
            {
                s1=0;
                s2++;
            }
            if (s2==6)
            {
                s2=0;
                m1++;
            }
            if (m1==10)
            {
                m1=0;
                m2++;
            }   
            if (m2==6)
            {
                m2=0;
                h1++;
            }
            if ((h1==10) && (h2==0))
            {
                h1=0;
                h2++;
            } 
            if ((h2==1)&&(h1==3))
            {
                h2=0;
                h1=1;
            }
            sprintf(clock,"%lu%lu:%lu%lu:%lu%lu\n\r",h2,h1,m2,m1,s2,s1);
            UART_UartPutString(clock);
            timer_flag=0;
        }

        // code for c input from user
        if (c_flag==1)
        {
            UART_UartPutString("Set clock time in hh:mm:ss format\r\n");
            while(uart_f4==0); // set h2 spot
            uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0; //reset all flags
            h2=input-48;        
            sprintf(display,"%lu",h2);
            UART_UartPutString(display);
            
            if (h2==1) // set h1 spot
            {
                while(uart_f3==0);
                uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
                h1=input-48;        
                sprintf(display,"%lu:",h1);
                UART_UartPutString(display);
            } else
            {
                while(uart_f1==0);
                uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
                h1=input-48;
                if (h1==0)
                {
                    h1=1; //switches a 0 with 1 to prevent 00:00:00
                }
                sprintf(display,"%lu:",h1);
                UART_UartPutString(display);
            }
            
            while(uart_f2==0); // set m2 spot
            uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
            m2=input-48;        
            sprintf(display,"%lu",m2);
            UART_UartPutString(display);
            
            while(uart_f1==0); // set m1 spot
            uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
            m1=input-48;        
            sprintf(display,"%lu:",m1);
            UART_UartPutString(display);
            
            while(uart_f2==0); // set s2 spot
            uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
            s2=input-48;        
            sprintf(display,"%lu",s2);
            UART_UartPutString(display);
            
            while(uart_f1==0); // set s1 spot
            uart_f4=0;uart_f3=0;uart_f2=0;uart_f1=0;
            s1=input-48;        
            sprintf(display,"%lu\n\r",s1);
            UART_UartPutString(display);
            
            c_flag=0;
            Timer_1_Init(); // resets the counter
            Timer_1_Start();
            
        }
    }
}
/* [] END OF FILE */