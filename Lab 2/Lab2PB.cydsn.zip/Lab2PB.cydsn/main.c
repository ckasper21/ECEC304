/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
int freq=1;
int sw_on=0;
int sw_off=1;

CY_ISR (uartISR)
{
    uint32 rxData;
    rxData=UART_UartGetChar();
    UART_UartPutChar(rxData); 
    UART_UartPutString("\r\n");
    if ((rxData >= 49 && rxData <=53) && sw_on==1)
    {
        freq=rxData-48;
    } else
    {
        UART_UartPutString("Invalid keyboard entry (or switch state is off)!\r\n");
    }
    UART_ClearRxInterruptSource(UART_GetRxInterruptSource());
}
CY_ISR (switchISR)
{
    CyDelay(50); 
    while(!Pin_SW2_Read()); // wait till switch is released
    CyDelay(50);
    if (sw_off==1)
    {
        sw_on=1;
        sw_off=0;
        UART_UartPutString("Switch is on!\r\n");
    } else 
    {
        sw_on=0;
        sw_off=1;
        UART_UartPutString("Switch is off!\r\n");
    }
    Pin_SW2_ClearInterrupt();
}
int main()
{
    CyGlobalIntDisable;
    Uart_Int_Start();
    Uart_Int_SetVector(uartISR);
    
    Pin_SW2_Int_Start();
    Pin_SW2_Int_SetVector(switchISR);
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();

    for(;;)
    {
        Pin_Red_Write(0);
        CyDelay(freq*1000); // leave switch on for 1 sec * amount of button press
        Pin_Red_Write(1);
        CyDelay(freq*1000);
    }
}

/* [] END OF FILE */